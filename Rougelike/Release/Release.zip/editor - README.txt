Left Click - Place char
Right Click - Remove char
Numpad 1 - Select w - wall
Numpad 2 - select @ - player
Numpad 0 - Clear map
Enter - Save to test.txt

If you want to load the map in the game you place it in the maps folder and press the period key
And that will load test.txt
Its not user friendly atm as its still wip
If you want to extend the game from the second level you canf use the > key to transition up a level
Like level2 -> level3 and the player will start from the @ symbol
You will have to manually place the 
D - dragons
S - slimes
> - level transition
for now